# SEO Checker - Free Domain Authority & Backlink Analysis Tool

A comprehensive web application for analyzing SEO metrics including Domain Authority, Page Authority, and backlink data using free APIs.

## Features

- **Bulk URL Analysis**: Check up to 10 domains simultaneously
- **Real SEO Metrics**: 
  - Domain Authority (DA)
  - Page Authority (PA) 
  - Authority Score
  - Total Backlinks
  - Quality Percentage
- **Responsive Design**: Works on desktop, tablet, and mobile
- **CSV Export**: Download results for further analysis
- **Real-time Processing**: AJAX-powered interface with loading indicators
- **Error Handling**: Graceful handling of API errors and invalid URLs

## Setup Instructions

### 1. Get API Key

1. Visit [OpenPageRank](https://www.domcop.com/openpagerank/auth/signup)
2. Sign up for a free account
3. Get your API key from the dashboard

### 2. Configure API Key

Edit `api.php` and replace `YOUR_API_KEY_HERE` with your actual API key:

\`\`\`php
const OPENPAGERANK_API_KEY = 'your_actual_api_key_here';
\`\`\`

### 3. Server Requirements

- PHP 7.0 or higher
- cURL extension enabled
- Web server (Apache, Nginx, etc.)

### 4. Installation

1. Upload all files to your web server
2. Ensure PHP has write permissions (for error logging)
3. Access `index.html` in your browser

## Usage

1. Enter URLs in the text area (one per line or comma-separated)
2. Click "Analyze SEO Metrics"
3. View results in the table
4. Download results as CSV if needed

## API Information

This tool uses the **OpenPageRank API** which provides:
- Free tier with 10,000 requests per hour
- Domain authority metrics based on open data
- No subscription required
- Real PageRank calculations

## File Structure

\`\`\`
seo-checker/
├── index.html          # Main HTML interface
├── styles.css          # CSS styling
├── script.js           # Frontend JavaScript
├── api.php             # Backend PHP API handler
└── README.md           # This file
\`\`\`

## Technical Details

### Frontend (JavaScript)
- Pure vanilla JavaScript (no frameworks)
- AJAX requests for real-time data
- Responsive design with CSS Grid/Flexbox
- CSV export functionality

### Backend (PHP)
- RESTful API design
- cURL for external API calls
- Input validation and sanitization
- Error handling and logging

### APIs Used
- **OpenPageRank API**: Primary source for domain authority data
- Calculations for estimated backlinks and quality scores

## Limitations

- Maximum 10 URLs per request (API limitation)
- Rate limited to 10,000 requests per hour
- Some metrics are estimated based on available data
- Requires active internet connection

## Troubleshooting

### Common Issues

1. **"API key not configured"**
   - Solution: Set your API key in `api.php`

2. **"cURL Error"**
   - Solution: Ensure cURL is enabled in PHP

3. **"Domain not found"**
   - Solution: Check URL format, ensure domain exists

4. **Rate limit exceeded**
   - Solution: Wait an hour or upgrade API plan

## License

This project is open source and available under the MIT License.

## Support

For issues or questions:
1. Check the troubleshooting section
2. Verify your API key is correct
3. Ensure all files are uploaded correctly
4. Check PHP error logs for detailed error messages
