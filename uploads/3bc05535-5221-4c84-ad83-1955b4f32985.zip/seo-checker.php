<?php
/*
Plugin Name: SEO Checker
Description: SEO Checker plugin wrapping your standalone tool.
Version: 1.3
Author: Syed Bilal Shah
*/

if ( ! defined( 'ABSPATH' ) ) exit;

// Enqueue CSS & JS only if shortcode is present on the page
function seo_checker_enqueue_assets() {
    global $post;

    // ✅ These 2 lines protect other pages:
    if ( isset($post->post_content) && has_shortcode($post->post_content, 'seo_checker') ) {
        wp_enqueue_style( 'seo-checker-styles', plugins_url( 'styles.css', __FILE__ ) );
        wp_enqueue_script( 'seo-checker-script', plugins_url( 'script.js', __FILE__ ), [], '1.3', true );

        // Pass api.php URL to JS
        wp_localize_script( 'seo-checker-script', 'seoCheckerVars', [
            'apiUrl' => plugins_url( 'api.php', __FILE__ )
        ]);
    }
}
add_action( 'wp_enqueue_scripts', 'seo_checker_enqueue_assets' );

// Shortcode output
function seo_checker_shortcode() {
    ob_start();
    include plugin_dir_path( __FILE__ ) . 'index.html';
    return ob_get_clean();
}
add_shortcode( 'seo_checker', 'seo_checker_shortcode' );
