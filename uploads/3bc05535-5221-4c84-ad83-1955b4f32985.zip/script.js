class SEOChecker {
  constructor() {
    this.form = document.getElementById("seoForm")
    this.urlsInput = document.getElementById("urls")
    this.analyzeBtn = document.getElementById("analyzeBtn")
    this.resultsSection = document.getElementById("resultsSection")
    this.resultsBody = document.getElementById("resultsBody")
    this.errorSection = document.getElementById("errorSection")
    this.errorText = document.getElementById("errorText")
    this.downloadBtn = document.getElementById("downloadCsv")

    this.currentResults = []

    this.init()
  }

  init() {
    this.form.addEventListener("submit", (e) => this.handleSubmit(e))
    this.downloadBtn.addEventListener("click", () => this.downloadCSV())
    
    // Add input validation for single domain
    this.urlsInput.addEventListener("input", () => this.validateSingleDomain())
  }
  
  validateSingleDomain() {
    const input = this.urlsInput.value.trim()
    
    // Check if multiple domains are entered (separated by newlines, commas, or semicolons)
    const separators = /[,;\n]/
    const parts = input.split(separators).map(part => part.trim()).filter(part => part.length > 0)
    
    if (parts.length > 1) {
      this.showSingleDomainError()
      this.analyzeBtn.disabled = true
      return false
    } else {
      this.hideSingleDomainError()
      this.analyzeBtn.disabled = false
      return true
    }
  }
  
  showSingleDomainError() {
    // Create error element if it doesn't exist
    let errorEl = document.getElementById("singleDomainError")
    if (!errorEl) {
      errorEl = document.createElement("div")
      errorEl.id = "singleDomainError"
      errorEl.style.color = "#dc3545"
      errorEl.style.fontWeight = "600"
      errorEl.style.marginTop = "8px"
      errorEl.style.fontSize = "14px"
      this.urlsInput.parentNode.appendChild(errorEl)
    }
    errorEl.textContent = "⚠️ Only one domain is allowed at a time"
    this.urlsInput.style.borderColor = "#dc3545"
    this.urlsInput.style.boxShadow = "0 0 0 3px rgba(220, 53, 69, 0.1)"
  }
  
  hideSingleDomainError() {
    const errorEl = document.getElementById("singleDomainError")
    if (errorEl) {
      errorEl.remove()
    }
    this.urlsInput.style.borderColor = ""
    this.urlsInput.style.boxShadow = ""
  }

  async handleSubmit(e) {
    e.preventDefault()

    // Validate single domain before proceeding
    if (!this.validateSingleDomain()) {
      return
    }

    const urls = this.parseUrls(this.urlsInput.value)

    if (urls.length === 0) {
      this.showError("Please enter at least one valid URL")
      return
    }

    if (urls.length > 1) {
      this.showError("Only one domain is allowed at a time")
      return
    }

    this.setLoading(true)
    this.hideError()
    this.hideResults()

    try {
      const results = await this.analyzeSEO(urls)
      this.displayResults(results)
    } catch (error) {
      this.showError(`Analysis failed: ${error.message}`)
    } finally {
      this.setLoading(false)
    }
  }

  parseUrls(input) {
    const urls = input
      .split(/[\n,;]/)
      .map((url) => url.trim())
      .filter((url) => url.length > 0)
      .map((url) => {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
          return url.startsWith("www.") ? `https://${url}` : `https://www.${url}`
        }
        return url
      })
      .map((url) => {
        try {
          const domain = new URL(url).hostname.replace("www.", "")
          return domain
        } catch {
          return url.replace(/^https?:\/\/(www\.)?/, "").split("/")[0]
        }
      })

    return [...new Set(urls)]
  }

  async analyzeSEO(domains) {
    const response = await fetch(seoCheckerVars.apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domains }),
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    if (data.error) throw new Error(data.error)

    return data.results || []
  }

  displayResults(results) {
    this.currentResults = results
    this.resultsBody.innerHTML = ""

    results.forEach((result) => {
      const row = this.createResultRow(result)
      this.resultsBody.appendChild(row)
    })

    this.showResults()
  }

  createResultRow(result) {
    const row = document.createElement("tr")

    const domainCell = document.createElement("td")
    domainCell.textContent = result.domain

    const daCell = document.createElement("td")
    daCell.innerHTML = this.formatMetric(result.domain_authority, "DA")

    const paCell = document.createElement("td")
    paCell.innerHTML = this.formatMetric(result.page_authority, "PA")

    const spamCell = document.createElement("td")
    spamCell.innerHTML = this.formatPercentage(result.spam_score)

    const statusCell = document.createElement("td")
    statusCell.innerHTML = `<span class="DA_status-${result.status === "success" ? "success" : "error"}">
      ${result.status === "success" ? "✅ Success" : "❌ " + (result.error || "Failed")}
    </span>`

    row.appendChild(domainCell)
    row.appendChild(daCell)
    row.appendChild(paCell)
    row.appendChild(spamCell)
    row.appendChild(statusCell)

    return row
  }

  formatMetric(value, type) {
    if (value === null || value === undefined) {
      return '<span class="DA_metric-low">N/A</span>'
    }

    const numValue = Number.parseFloat(value)
    let className = "DA_metric-low"
    if (numValue >= 70) className = "DA_metric-high"
    else if (numValue >= 40) className = "DA_metric-medium"

    return `<span class="${className}">${numValue}${type === "Score" ? "/100" : ""}</span>`
  }

  formatNumber(value) {
    if (value === null || value === undefined) return "N/A"
    return Number.parseInt(value).toLocaleString()
  }

  formatPercentage(value) {
    if (value === null || value === undefined) return "N/A"
    const numValue = Number.parseFloat(value)
    let className = "DA_metric-low"

    if (numValue <= 2) className = "DA_metric-high"
    else if (numValue <= 5) className = "DA_metric-medium"

    return `<span class="${className}">${numValue}%</span>`
  }

  setLoading(loading) {
    const btnText = this.analyzeBtn.querySelector(".DA_btn-text")
    const spinner = this.analyzeBtn.querySelector(".DA_loading-spinner")

    if (loading) {
      btnText.style.display = "none"
      spinner.style.display = "flex"
      this.analyzeBtn.disabled = true
    } else {
      btnText.style.display = "inline"
      spinner.style.display = "none"
      // Only re-enable if no validation error
      if (this.validateSingleDomain()) {
        this.analyzeBtn.disabled = false
      }
    }
  }

  showResults() {
    this.resultsSection.style.display = "block"
    this.resultsSection.scrollIntoView({ behavior: "smooth" })
  }

  hideResults() {
    this.resultsSection.style.display = "none"
  }

  showError(message) {
    this.errorText.textContent = message
    this.errorSection.style.display = "block"
    this.errorSection.scrollIntoView({ behavior: "smooth" })
  }

  hideError() {
    this.errorSection.style.display = "none"
  }

  downloadCSV() {
    if (this.currentResults.length === 0) return

    const headers = ["Domain", "Domain Authority", "Page Authority", "Spam Score", "Status"]
    const csvContent = [
      headers.join(","),
      ...this.currentResults.map((result) =>
        [
          result.domain,
          result.domain_authority || "N/A",
          result.page_authority || "N/A",
          result.spam_score || "N/A",
          result.status,
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `seo-analysis-${new Date().toISOString().split("T")[0]}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    window.URL.revokeObjectURL(url)
  }
}

document.addEventListener("DOMContentLoaded", () => {
  new SEOChecker()
})