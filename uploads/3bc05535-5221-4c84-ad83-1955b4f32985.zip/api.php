<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$input = json_decode(file_get_contents("php://input"), true);
$domains = $input["domains"] ?? [];

if (empty($domains)) {
    echo json_encode(["error" => "No domains provided"]);
    exit;
}

// Moz API credentials
$accessID = "mozscape-hdPV3e76GY";
$secretKey = "63BqM0XJuUGmDwyo0yfH7IjzMXef2nCQ";

// Expire time (Unix epoch time in seconds)
$expires = time() + 300;

// Create string to sign
$stringToSign = $accessID . "\n" . $expires;

// Create signature
$binarySignature = hash_hmac('sha1', $stringToSign, $secretKey, true);
$urlSafeSignature = urlencode(base64_encode($binarySignature));

$results = [];

foreach ($domains as $domain) {
    $url = "https://lsapi.seomoz.com/v2/url_metrics";

    $postData = json_encode([
        "targets" => [$domain],
        "metrics" => [
            "domain_authority",
            "page_authority",
            "spam_score",
            "external_pages_to_url",
            "external_nofollow_pages_to_url"
        ]
    ]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Authorization: Basic " . base64_encode("$accessID:$secretKey")
    ]);

    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpcode == 200 && $response) {
        $data = json_decode($response, true);
        $metrics = $data['results'][0] ?? [];

        $results[] = [
            "domain" => $domain,
            "domain_authority" => $metrics['domain_authority'] ?? null,
            "page_authority" => $metrics['page_authority'] ?? null,
            "spam_score" => $metrics['spam_score'] ?? null,
            "status" => "success"
        ];
    } else {
        $results[] = [
            "domain" => $domain,
            "status" => "error",
            "error" => "Failed with HTTP $httpcode"
        ];
    }
}

echo json_encode(["results" => $results]);
